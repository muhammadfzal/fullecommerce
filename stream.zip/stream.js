const fs = require("fs");
fs.readFile("test.json", (err, data) => {
  if (err) throw err;
  const dataa = JSON.parse(data);
  setInterval(() => {
    console.log(dataa);
  }, 2000);
});
